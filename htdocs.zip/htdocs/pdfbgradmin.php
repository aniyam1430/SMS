<?php 
require "fpdf.php";
$conn = new PDO('mysql:host=localhost;dbname=aditya','root','');
//error_reporting(0);
class myPDF extends FPDF{
    function header(){
        $this->SetFont('Arial','B',14);
        $this->Cell(276,5,'Ground Booking Report',0,0,'C');
        $this->Ln();
        $this->SetFont('Times','',12);
        $this->Cell(276,10,"Sport's Club" ,0,0,'C');
        $this->Ln(20);
    }
    function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
    function headerTable(){
        $this->SetFont('Times','B',12);
        $this->Cell(30,10,'Ground ID',1,0,'C');
        $this->Cell(20,10,'User ID',1,0,'C');
        $this->Cell(60,10,'Start date-time',1,0,'C');
        $this->Cell(60,10,'End date-time',1,0,'C');
        $this->Cell(38,10,'Total Member',1,0,'C');
        $this->Cell(40,10,'Details',1,0,'C');
        
        $this->Ln();
    }
    function viewTable($conn){
        $this->SetFont('Times','',12);
        $stmt = $conn->query('select * from tbl_register_ground');
        while($data = $stmt->fetch(PDO::FETCH_OBJ)){
            $this->Cell(30,10,$data->Ground_id,1,0,'C');
            $this->Cell(20,10,$data->User_id,1,0,'C');
            $this->Cell(60,10,$data->Startdatetime,1,0,'C');
            $this->Cell(60,10,$data->Enddatetime,1,0,'C');
            $this->Cell(38,10,$data->Totalmember,1,0,'C');
            $this->Cell(40,10,$data->Details,1,0,'C');
            $this->Ln();
        }
    }
}

$pdf = new myPDF();
$pdf->AliasNbPages();
$pdf->AddPage('L','A4',0);
$pdf->headerTable();
$pdf->viewTable($conn);
$pdf->Output();