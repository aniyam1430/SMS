<?php 
require "fpdf.php";
$conn = new PDO('mysql:host=localhost;dbname=aditya','root','');
//error_reporting(0);
class myPDF extends FPDF{
    function header(){
        $this->SetFont('Arial','B',14);
        $this->Cell(276,5,'Report of Grounds',0,0,'C');
        $this->Ln();
        $this->SetFont('Times','',12);
        $this->Cell(276,10,"Sport's Club" ,0,0,'C');
        $this->Ln(20);
    }
    function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
    function headerTable(){
        $this->SetFont('Times','B',12);
        $this->Cell(20,10,'G_id',1,0,'C');
        $this->Cell(80,10,'Name',1,0,'L');
        $this->Cell(80,10,'Details',1,0,'L');
        $this->Cell(30,10,'Ground Type Id',1,0,'C');
        $this->Cell(38,10,'Max Strength',1,0,'C');
        $this->Cell(30,10,'Rent (Per day)',1,0,'C');
        $this->Ln();
    }
    function viewTable($conn){
        $this->SetFont('Times','',12);
        $stmt = $conn->query('select * from tbl_ground');
        while($data = $stmt->fetch(PDO::FETCH_OBJ)){
            $this->Cell(20,10,$data->G_id,1,0,'C');
            $this->Cell(80,10,$data->G_name,1,0,'L');
            $this->Cell(80,10,$data->G_details,1,0,'L');
            $this->Cell(30,10,$data->G_type_id,1,0,'C');
            $this->Cell(38,10,$data->Max_strength,1,0,'C');
            $this->Cell(30,10,$data->rent,1,0,'C');
            $this->Ln();
        }
    }
}

$pdf = new myPDF();
$pdf->AliasNbPages();
$pdf->AddPage('L','A4',0);
$pdf->headerTable();
$pdf->viewTable($conn);
$pdf->Output();