<?php
session_start();
include('connect.php');

if(isset($_POST['reg'])){
$name = $_POST['firstname'];
$fname = $_POST['lastname'];
$dateofbirth = $_POST['dob'];
$gender= $_POST['gen'];
$address = $_POST['Address'];
$city = $_POST['city'];
$pcode = $_POST['pcode'];
$state = $_POST['state'];
$mob = $_POST['mob'];
$mail = $_POST['mail'];
$uname = $_POST['uname'];
$cpwd = $_POST['cpwd'];
$interest = $_POST['interest'];
    
$image = $_FILES['image']['name'];
$tmpimage = $_FILES['image']['tmp_name'];
$folder = 'userimage';
$target_file = $folder.'/'.basename($_FILES['image']['name']);
    
 if(move_uploaded_file($tmpimage, $target_file)){
      echo 'hdvsjcjdscsjsdvchsdbcsd';
$qry = "insert into registration(firstname, lastname, gender, dob, address, city, pcode, state, uname, cpwd, email, mobile, interestedin, profile) values('$name', '$fname', '$gender', '$dateofbirth', '$address', '$city', '$pcode', '$state','$uname', '$cpwd', '$mail', '$mob', '$interest', '$image')";
    
 $ani = mysqli_query($conn, $qry);
     
 }
    
if($ani){
	$msg =  "successfully register";
	header('location:index.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:registration.php?msg='.$msg);
} 
 
}


if(isset($_POST['admreg'])){
$name = $_POST['firstname'];
$dateofbirth = $_POST['dob'];
$gender= $_POST['gen'];
$mob = $_POST['mob'];
$mail = $_POST['mail'];
$uname = $_POST['uname'];
$address = $_POST['Address'];
$cpwd = $_POST['password'];   
$image = $_FILES['image']['name'];
$tmpimage = $_FILES['image']['tmp_name'];
$folder = 'userimage';
$target_file = $folder.'/'.basename($_FILES['image']['name']);
    
 if(move_uploaded_file($tmpimage, $target_file)){
$qry = "insert into admin(name, dob, email, address, gender, username, password, profile, mobile, isactive) values('$name', '$dateofbirth', '$mail', '$address', '$gender', '$uname', '$cpwd', '$target_file', '$mob','offline')";
    
 $ani = mysqli_query($conn, $qry);
     
 }
    
if($ani){
	$msg =  "Admin successfully register";
	header('location:index.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:adminreg.php?msg='.$msg);
} 
 
}


$adi="ashwiniiojha1014";
$ani="123456";
if(isset($_POST['login']))
{
  $b=$_POST['username'];
  $b1=$_POST['pass'];
  
  $result=mysqli_query($conn,"select * from registration where uname='$b' and cpwd='$b1' ");
  $coun=mysqli_num_rows($result); 
  if($coun==1)
   {
      $_SESSION['username']=$b;
	header('location:user.php');
    }
    elseif($b!="" && $b1!="")
      {
         $result1=mysqli_query($conn,"select * from admin where username='$b' and password='$b1' ");
            $coun1=mysqli_num_rows($result1); 
        if($coun1==1)
            {
                $_SESSION['username']=$b;
                header('location:admin.php');
            }
    
}
else{
    $msg =  "Either Username or Password is wrong";
	header("location:index.php?msg=".$msg);
}

}

if(isset($_POST['addg'])){
    
$name = $_POST['name'];
$fname = $_POST['detail'];
$status= $_POST['status'];
$type = $_POST['type'];
$strength = $_POST['strength'];
$rent = $_POST['rent'];
$image = $_FILES['image']['name'];
$tmpimage1 = $_FILES['image']['tmp_name'];
$folder = 'groundimage';
$target_file1 = $folder.'/'.basename($_FILES['image']['name']);
    
    
$qry1 = "insert into tbl_ground_type(G_type_name, G_type_details, Image_path) values('$type', '$name', '$image')";
$result1 = mysqli_query($conn, $qry1);
    
$sql2 = "select * from tbl_ground_type where G_type_details = '$name' ";
$result2 = mysqli_query($conn, $sql2);
$rows = mysqli_fetch_array($result2);
$gid = $rows['G_type_id']; 
    

if(move_uploaded_file($tmpimage1, $target_file1)){
$qry = "insert into tbl_ground(G_name, G_details, Status, G_type_id, Max_strength, rent, Image_path) values('$name', '$fname', '$status', '$gid', '$strength', '$rent', '$target_file1')";
$result = mysqli_query($conn, $qry);
 }
if($result1 && $result ){
	$msg =  "successfully Added Ground";
	header('location:admin.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:admin.php?msg='.$msg);
} 
}


if(isset($_POST['addgallery'])){
    
$name = $_POST['name'];
$fname = $_POST['detail'];
$status= $_POST['status'];
$image = $_FILES['image']['name'];
$tmpimage1 = $_FILES['image']['tmp_name'];
$folder = 'galleryimage';
$target_file1 = $folder.'/'.basename($_FILES['image']['name']);
     if(move_uploaded_file($tmpimage1, $target_file1)){   
       $qry = "insert into tbl_gallery(Gal_title, Gal_details, status, Img_path) values('$name', '$fname', '$status', '$target_file1')";
       $result = mysqli_query($conn, $qry);
         
       $sql2 = "select * from tbl_gallery where Gal_title = '$name' ";
       $result2 = mysqli_query($conn, $sql2);
       $rows = mysqli_fetch_array($result2);
       $gid = $rows['Gal_id'];  
         
      $qry1 = "insert into tbl_gallert_image(Gal_id, Img_path, Img_details) values('$gid', '$target_file1', '$name')";
     $result1 = mysqli_query($conn, $qry1);
     }
if($result){
	$msg =  "successfully added gallery";
	header('location:agadmin.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:agadmin.php?msg='.$msg);
} 
}



if(isset($_POST['bg'])){
    
$name = $_POST['name'];
$std = $_POST['std'];
$edd = $_POST['edd'];
$tm = $_POST['tm'];
$detail = $_POST['detail'];
$uid = $_POST['uid'];
$status = $_POST['status'];
    
$sql = "select * from tbl_ground where G_name = '$name' ";
$result = mysqli_query($conn, $sql);
$rows = mysqli_fetch_array($result);
$gid = $rows['G_id'];   

$qry = "insert into tbl_register_ground(User_id, Ground_id, Startdatetime, Enddatetime, Details, Totalmember, Status) values('$uid', '$gid', '$std', '$edd', '$detail', '$tm', '$status')";
$result = mysqli_query($conn, $qry);
if($result){
	$msg =  "you are successfully register your request for ground booking";
	header('location:bguser.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:bguser.php?msg='.$msg);
} 
}

if(isset($_POST['gf'])){
    
$name = $_POST['name'];
$email = $_POST['mail'];
$detail = $_POST['detail'];
$msg = $_POST['msg'];

$qry = "insert into tbl_feedback(Name, Email_id, Mobile_no, Message) values('$name', '$email', '$detail', '$msg')";
$result = mysqli_query($conn, $qry);
if($result){
	$msg =  "Your feedback is successfully submitted";
	header('location:gfuser.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:gfuser.php?msg='.$msg);
} 
}

if(isset($_POST['update'])){
    
$name = $_POST['name'];
$fname = $_POST['detail'];
$status= $_POST['status'];
$type = $_POST['type'];
$strength = $_POST['strength'];
$rent = $_POST['rent'];
$id = $_POST['id'];

$sql2 = "select * from tbl_ground where G_id = '$id' ";
$result2 = mysqli_query($conn, $sql2);
$rows2 = mysqli_fetch_array($result2);
$gname = $rows2['G_name'];   
    
$qry = "UPDATE `tbl_ground` SET `G_name`='$name',`G_details`='$fname', `Max_strength`='$strength',`rent`='$rent' WHERE G_id='$id' ";
$result = mysqli_query($conn, $qry);
    
$qry1 = "UPDATE `tbl_ground_type` SET `G_type_name`='$type',`G_type_details`='$name' WHERE G_type_details = '$gname' ";
$result1 = mysqli_query($conn, $qry1);
if($result && $result1 ){
	$msg =  "Your update is successfully submitted";
	header('location:update.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:update.php?msg='.$msg);
} 
}

if(isset($_POST['approval'])){
    
$name = $_POST['type'];
$gid = $_POST['gid'];
    
$qry1 = "UPDATE `tbl_register_ground` SET `Status`='$name' WHERE Ground_id = '$gid' ";
$result1 = mysqli_query($conn, $qry1);

$qry2 = "UPDATE `tbl_ground` SET `Status`='$name' WHERE G_id = '$gid' ";
$result2 = mysqli_query($conn, $qry2);
    
$sql2 = "select * from tbl_ground where G_id = '$gid' ";
$result2 = mysqli_query($conn, $sql2);
$rows2 = mysqli_fetch_array($result2);
$gname = $rows2['G_type_id'];   
    
$qry3 = "UPDATE `tbl_ground_type` SET `Status`='$name' WHERE G_type_id = '$gname' ";
$result3 = mysqli_query($conn, $qry3);
    
if($result1 && $result2 && $result3 ){
	$msg =  "Your update is successfully submitted";
	header('location:baadmin.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:baadmin.php?msg='.$msg);
} 
}



if(isset($_GET['deleteuser']))
{
$id = $_GET['deleteuser'];
$qry = "delete from registration where reg_id='$id' ";
if(mysqli_query($conn, $qry)){
	$msg =  "delete successfully";
	header('location:mmadmin.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:mmadmin.php?msg='.$msg);
}
    
}

if(isset($_GET['deleteground']))
{
$id = $_GET['deleteground'];
$qry = "delete from tbl_ground where G_id='$id' ";
if(mysqli_query($conn, $qry)){
	$msg =  "delete successfully";
	header('location:vgadmin.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:vgadmin.php?msg='.$msg);
}
    
}

if(isset($_GET['deletefeedback']))
{
$id = $_GET['deleteground'];
$qry = "delete from tbl_feedback where f_id='$id' ";
if(mysqli_query($conn, $qry)){
	$msg =  "delete successfully";
	header('location:vfadmin.php?msg='.$msg);
}else{
	$msg =  "error";
	header('location:vfadmin.php?msg='.$msg);
}
    
}
?>