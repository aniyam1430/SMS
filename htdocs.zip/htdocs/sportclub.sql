-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 28, 2018 at 10:26 AM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sport'sclub`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE IF NOT EXISTS `registration` (
  `reg_id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pcode` int(6) NOT NULL,
  `state` varchar(20) NOT NULL,
  `uname` varchar(15) NOT NULL,
  `cpwd` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `mobile` int(10) NOT NULL,
  `isactive` bit(2) NOT NULL,
  `interestedin` varchar(50) NOT NULL,
  PRIMARY KEY (`reg_id`),
  UNIQUE KEY `Email` (`email`),
  UNIQUE KEY `User_name` (`uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

DROP TABLE IF EXISTS `tbl_feedback`;
CREATE TABLE IF NOT EXISTS `tbl_feedback` (
  `f_id` int(10) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) NOT NULL,
  `Email_id` varchar(50) NOT NULL,
  `Mobile_no` varchar(10) NOT NULL,
  `Message` varchar(255) NOT NULL,
  PRIMARY KEY (`f_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallert_image`
--

DROP TABLE IF EXISTS `tbl_gallert_image`;
CREATE TABLE IF NOT EXISTS `tbl_gallert_image` (
  `Gal_img_id` int(10) NOT NULL AUTO_INCREMENT,
  `Gal_id` int(10) NOT NULL,
  `Img_path` varchar(50) NOT NULL,
  `Isdefault` bit(2) NOT NULL,
  `Img_details` varchar(255) NOT NULL,
  `Status` bit(2) NOT NULL,
  PRIMARY KEY (`Gal_img_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

DROP TABLE IF EXISTS `tbl_gallery`;
CREATE TABLE IF NOT EXISTS `tbl_gallery` (
  `Gal_id` int(10) NOT NULL AUTO_INCREMENT,
  `Gal_title` varchar(50) NOT NULL,
  `Gal_details` varchar(255) NOT NULL,
  `status` bit(2) NOT NULL,
  `Img_path` varchar(50) NOT NULL,
  PRIMARY KEY (`Gal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ground`
--

DROP TABLE IF EXISTS `tbl_ground`;
CREATE TABLE IF NOT EXISTS `tbl_ground` (
  `G_id` int(10) NOT NULL AUTO_INCREMENT,
  `G_name` varchar(50) NOT NULL,
  `G_details` varchar(150) NOT NULL,
  `Status` bit(2) NOT NULL,
  `G_type_id` int(10) NOT NULL,
  `Max_strength` varchar(50) NOT NULL,
  `Image_path` varchar(50) NOT NULL,
  PRIMARY KEY (`G_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ground_img`
--

DROP TABLE IF EXISTS `tbl_ground_img`;
CREATE TABLE IF NOT EXISTS `tbl_ground_img` (
  `G_img_id` int(10) NOT NULL AUTO_INCREMENT,
  `G_id` int(10) NOT NULL,
  `Image_path` varchar(50) NOT NULL,
  `Isdefault` bit(2) NOT NULL,
  `Image_details` varchar(150) NOT NULL,
  `Status` bit(2) NOT NULL,
  PRIMARY KEY (`G_img_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ground_type`
--

DROP TABLE IF EXISTS `tbl_ground_type`;
CREATE TABLE IF NOT EXISTS `tbl_ground_type` (
  `G_type_id` int(10) NOT NULL AUTO_INCREMENT,
  `G_type_name` varchar(50) NOT NULL,
  `G_type_details` varchar(150) NOT NULL,
  `Status` bit(2) NOT NULL,
  `Image_path` varchar(50) NOT NULL,
  PRIMARY KEY (`G_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_register_ground`
--

DROP TABLE IF EXISTS `tbl_register_ground`;
CREATE TABLE IF NOT EXISTS `tbl_register_ground` (
  `Reg_g_id` int(10) NOT NULL AUTO_INCREMENT,
  `User_id` varchar(50) NOT NULL,
  `Ground_id` int(10) NOT NULL,
  `Startdatetime` datetime(6) NOT NULL,
  `Enddatetime` datetime(6) NOT NULL,
  `Isapproved` bit(2) NOT NULL,
  `Details` varchar(150) NOT NULL,
  `Totalmember` tinyint(3) NOT NULL,
  `Status` bit(2) NOT NULL,
  PRIMARY KEY (`Reg_g_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
