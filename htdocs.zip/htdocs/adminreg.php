<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sport's Club</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/w3.css">
<!--===============================================================================================-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
    function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
    </script>
    
<style>
    #message {
  display:none;
  background: #f1f1f1;
  color: #000;
  position: relative;
  padding: 20px;
  margin-top: 10px;
}

#message p {
  padding: 10px 35px;
  font-size: 18px;
}

/* Add a green text color and a checkmark when the requirements are right */
.valid {
  color: green;
}

.valid:before {
  position: relative;
  left: -35px;
  content: "✔";
}

/* Add a red text color and an "x" when the requirements are wrong */
.invalid {
  color: red;
}

.invalid:before {
  position: relative;
  left: -35px;
  content: "✖";
}
    #error_msg {
  color: red;
  text-align: center;
  margin: 10px auto;
}
    </style>
</head>
<body>
	

	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-02.jpg');">
             <!-- Navbar -->
<div class="w3-top" style="overflow:inherit; position: fixed">
  <div class="w3-bar w3-card" style="background-color:linear-gradient(top, #7579ff, #b224ef); color:blueviolet;">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" style="margin-top: 20px;" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="index.php" class="w3-bar-item w3-button w3-padding-large"><span style="font-size: 36px; font-family: Brush Script MT, cursive;">Sport's Club</span></a>
    <span class="w3-right" style="margin-top: 20px;"><a href="#band" class="w3-bar-item w3-center w3-button w3-padding-large w3-hide-small">HOME</a>
    <a href="#band" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GAMES</a>
    <a href="#tour" class="w3-bar-item w3-button w3-padding-large w3-hide-small">GROUNDS</a>
    <a href="#contact" class="w3-bar-item w3-button w3-padding-large w3-hide-small">ABOUT US</a>
    <a href="#contact" class="w3-bar-item w3-button w3-padding-large w3-hide-small">CONTACT US</a></span>
  </div>
</div>

<!-- Navbar on small screens (remove the onclick attribute if you want the navbar to always show on top of the content when clicking on the links) -->
<div id="navDemo" class="w3-bar-block w3-black w3-hide w3-hide-large w3-hide-medium w3-top" style="margin-top:75px">
  <a href="#band" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">HOME</a>
  <a href="#band" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">GAMES</a>
  <a href="#tour" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">GROUNDS</a>
  <a href="#contact" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">ABOUT US</a>
  <a href="#band" class="w3-bar-item w3-button w3-padding-large" onclick="myFunction()">CONTACT US</a>
</div>

			<div class="wrap-login100" style="margin-top: 10%;">
				<form action="controller.php" method="post" class="login100-form validate-form" enctype="multipart/form-data" validate>
					<span class="login100-form-title p-b-34 p-t-27">
						Sign Up
					</span>

                    <span class="login100-form-title p-b-34 p-t-27">
						Personal Details
					</span>
					<div class="wrap-input100 validate-input" data-validate = "Enter your name">
						<input class="input100" type="text" name="firstname" placeholder="Your name">
						<span class="focus-input100" data-placeholder="&#xf207;"></span>
					</div>
                    
                    <div class="wrap-input100 validate-input" data-validate="Select Gender">
						<select class="input100" name="gen" placeholder="Select Gender">
                        <option value="Male" selected>Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                        </select>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                    
                    <div class="wrap-input100 validate-input" data-validate="Enter Date of birth">
						<input class="input100" type="date" name="dob" placeholder="Date of Birth">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                    
                    <div class="wrap-input100 validate-input" data-validate="Please select your image">
						<input class="input100" type="file" name="image" multiple placeholder="Select image for profile">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                    
                    <span class="login100-form-title p-b-34 p-t-27">
						Contact Details
					</span>
                    
                    <div class="wrap-input100 validate-input" data-validate="Enter Address">
                        <textarea class="input100" type="text" name="Address" placeholder="Address"></textarea>
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                    
                    <div class="wrap-input100 validate-input" data-validate="Enter Email">
						<input class="input100" type="email" id="mail" name="mail" placeholder="Enter your E-mail">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                     <span></span>
                    <div class="wrap-input100 validate-input" data-validate="Enter Mobile numbere">
						<input class="input100" type="text" name="mob" placeholder="Enter your mobile number" >
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                    
                    <span class="login100-form-title p-b-34 p-t-27">
						Login Details
					</span>
                    
                    <div class="wrap-input100 validate-input" data-validate="Create username">
						<input class="input100" type="text" name="uname" name="uname" placeholder="Create your username">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>
                     <span></span>
                    <div class="wrap-input100 validate-input" data-validate="Create password">
						<input class="input100" type="password" name="password" placeholder="Create your Pasword" id="psw">
						<span class="focus-input100" data-placeholder="&#xf191;"></span>
					</div>

					<div class="container-login100-form-btn">
						<button class="login100-form-btn" name="admreg">
							Sign up
						</button>
					</div>

					<div class="text-center p-t-90">
                        <label style="color: floralwhite;">
                        Already have account?
                        </label>
						<a class="txt1" href="index.php">
							Click Here
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>
    
	
	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>